import os
import textwrap

base = r"C:\Users\LENOVO\OneDrive\Desktop\agent bazar\backend\app"

files = {
    "api/__init__.py": "",
    "api/endpoints/__init__.py": """
from fastapi import APIRouter
from . import registry, discovery, transactions, demo

api_router = APIRouter()
api_router.include_router(registry.router, prefix="/services", tags=["services"])
api_router.include_router(discovery.router, prefix="/discovery", tags=["discovery"])
api_router.include_router(transactions.router, prefix="/transactions", tags=["transactions"])
api_router.include_router(demo.router, prefix="/demo", tags=["demo"])
    """,
    "api/endpoints/registry.py": """
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.models.domain import Service, Agent
from pydantic import BaseModel
from typing import List

router = APIRouter()

class ServiceCreate(BaseModel):
    agent_id: int
    name: str
    description: str
    endpoint: str
    price: float
    category: str

@router.post("/")
async def register_service(service: ServiceCreate, db: AsyncSession = Depends(get_db)):
    new_service = Service(**service.dict())
    db.add(new_service)
    await db.commit()
    await db.refresh(new_service)
    return new_service

@router.get("/")
async def list_services(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Service))
    return result.scalars().all()

@router.post("/{service_id}/execute")
async def execute_service(service_id: int):
    # If middleware didn't return 402, payment is assumed valid for demo purposes
    return {"status": "success", "data": f"Service {service_id} executed successfully with verified payment."}
    """,
    "api/endpoints/discovery.py": """
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.db.session import get_db
from app.models.domain import Service, Agent

router = APIRouter()

@router.get("/")
async def discover_agents(category: str = None, min_trust: float = None, db: AsyncSession = Depends(get_db)):
    query = select(Agent).options(selectinload(Agent.services))
    if min_trust is not None:
        query = query.where(Agent.trust_score >= min_trust)
    
    result = await db.execute(query)
    agents = result.scalars().all()
    
    # Optional category filter in python for simplicity if needed
    if category:
        agents = [a for a in agents if any(s.category == category for s in a.services)]
    
    return agents
    """,
    "api/endpoints/transactions.py": """
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.models.domain import Transaction

router = APIRouter()

@router.get("/")
async def get_transactions(wallet: str = None, db: AsyncSession = Depends(get_db)):
    query = select(Transaction)
    if wallet:
        query = query.where(Transaction.buyer_wallet == wallet)
    result = await db.execute(query)
    return result.scalars().all()
    """,
    "api/endpoints/demo.py": """
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.services.ai.negotiation import run_negotiation
from app.services.blockchain.provider import get_provider
from app.tasks.reputation import update_trust_score
import asyncio
import uuid

router = APIRouter()

@router.post("/scenario")
async def run_demo_scenario(db: AsyncSession = Depends(get_db)):
    # 1. Discovery
    # Mocking a discovered service
    service_info = {"id": 1, "name": "Sentiment Analysis", "price": 10.0, "agent_id": 2}
    
    # 2. Negotiation
    negotiated_price = await run_negotiation(buyer_budget=8.0, seller_price=service_info["price"])
    
    # 3. 402 Flow & Escrow
    provider = get_provider()
    tx_hash = await provider.lock_funds(amount=negotiated_price, buyer="BUYER_WALLET", escrow="ESCROW_ADDRESS")
    
    # 4. Execution (mock delay)
    await asyncio.sleep(2)
    
    # 5. Release Escrow
    await provider.release_funds(tx_hash=tx_hash)
    
    # 6. Reputation Update
    await update_trust_score(agent_id=service_info["agent_id"], event_type="success", db=db)
    
    return {
        "status": "completed",
        "pipeline": [
            {"step": "discovery", "message": "Found service Sentiment Analysis"},
            {"step": "negotiation", "message": f"Negotiated price: {negotiated_price} ALGO"},
            {"step": "402_payment", "message": "Received 402 Payment Required"},
            {"step": "escrow_lock", "message": f"Locked {negotiated_price} ALGO in smart contract", "tx": tx_hash},
            {"step": "execution", "message": "Service executed successfully"},
            {"step": "escrow_release", "message": "Funds released to seller"},
            {"step": "reputation", "message": "Seller trust score updated"}
        ]
    }
    """,
    "services/__init__.py": "",
    "services/blockchain/__init__.py": "",
    "services/blockchain/provider.py": """
import uuid
from app.core.config import settings

class PaymentProvider:
    async def lock_funds(self, amount: float, buyer: str, escrow: str) -> str:
        pass
    async def release_funds(self, tx_hash: str) -> bool:
        pass

class MockPaymentProvider(PaymentProvider):
    async def lock_funds(self, amount: float, buyer: str, escrow: str) -> str:
        return f"mock_tx_{uuid.uuid4().hex[:8]}"
        
    async def release_funds(self, tx_hash: str) -> bool:
        return True

class AlgorandPaymentProvider(PaymentProvider):
    async def lock_funds(self, amount: float, buyer: str, escrow: str) -> str:
        # Placeholder for py-algorand-sdk interaction
        return f"algo_tx_{uuid.uuid4().hex[:8]}"
        
    async def release_funds(self, tx_hash: str) -> bool:
        return True

def get_provider() -> PaymentProvider:
    if settings.PAYMENT_PROVIDER == "mock":
        return MockPaymentProvider()
    return AlgorandPaymentProvider()
    """,
    "services/blockchain/escrow.py": """
from pyteal import *

def approval_program():
    # Simple PyTeal escrow contract
    handle_optin = Return(Int(1))
    handle_closeout = Return(Int(1))
    handle_updateapp = Return(Int(0))
    handle_deleteapp = Return(Int(0))
    
    # Escrow release logic placeholder
    # In a real app this would verify completion of the service
    release_funds = Seq([
        # Log completion
        Return(Int(1))
    ])
    
    program = Cond(
        [Txn.application_id() == Int(0), Return(Int(1))],
        [Txn.on_completion() == OnComplete.OptIn, handle_optin],
        [Txn.on_completion() == OnComplete.CloseOut, handle_closeout],
        [Txn.on_completion() == OnComplete.UpdateApplication, handle_updateapp],
        [Txn.on_completion() == OnComplete.DeleteApplication, handle_deleteapp],
        [Txn.application_args[0] == Bytes("release"), release_funds]
    )
    return program

def clear_state_program():
    return Return(Int(1))
    """,
    "services/ai/__init__.py": "",
    "services/ai/negotiation.py": """
import asyncio

async def run_negotiation(buyer_budget: float, seller_price: float) -> float:
    # A LangGraph agent would normally run here.
    # For out-of-the-box demo without API keys, we simulate a successful negotiation.
    await asyncio.sleep(1) # simulate thinking
    agreed_price = (buyer_budget + seller_price) / 2
    return round(agreed_price, 2)
    """,
    "tasks/__init__.py": "",
    "tasks/reputation.py": """
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.domain import Agent, ReputationEvent

async def update_trust_score(agent_id: int, event_type: str, db: AsyncSession):
    event = ReputationEvent(
        agent_id=agent_id,
        event_type=event_type,
        weight=1.0 if event_type == "success" else -1.0
    )
    db.add(event)
    
    # Calculate new score
    agent = await db.get(Agent, agent_id)
    if agent:
        if event_type == "success":
            agent.trust_score = min(100.0, agent.trust_score + 2.5)
        else:
            agent.trust_score = max(0.0, agent.trust_score - 5.0)
            
    await db.commit()
    """
}

for rel_path, content in files.items():
    full_path = os.path.join(base, rel_path.replace("/", "\\"))
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w") as f:
        f.write(content.strip() + "\n")

print("Backend files generated.")

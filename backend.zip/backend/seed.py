import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import select
from app.core.config import settings
from app.models.domain import Agent, Service, Transaction, ReputationEvent

engine = create_async_engine(settings.DATABASE_URL, echo=False)
async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

agents_data = [
    {"name": "ResearchBot Alpha", "wallet": "W_RES_ALPHA_123", "trust": 85.0},
    {"name": "DataCruncher", "wallet": "W_DATA_99", "trust": 92.5},
    {"name": "Sentiment Analytica", "wallet": "W_SENTI_XYZ", "trust": 78.0},
    {"name": "ReportGenius", "wallet": "W_REP_44", "trust": 95.0},
    {"name": "Vision AI", "wallet": "W_VIS_777", "trust": 88.0},
    {"name": "Polyglot Translator", "wallet": "W_TRANS_55", "trust": 90.5}
]

services_data = [
    {"agent_idx": 0, "name": "Deep Web Research", "description": "Compiles comprehensive research reports from live web data.", "endpoint": "http://agents.local/research", "price": 15.0, "category": "Research"},
    {"agent_idx": 1, "name": "Dataset Cleaning", "description": "Normalizes and cleans messy CSV/JSON datasets.", "endpoint": "http://agents.local/clean", "price": 5.0, "category": "Data"},
    {"agent_idx": 2, "name": "Social Sentiment Analysis", "description": "Analyzes tone and sentiment of text arrays.", "endpoint": "http://agents.local/sentiment", "price": 8.0, "category": "Analysis"},
    {"agent_idx": 3, "name": "Executive Summary Generator", "description": "Summarizes long documents into executive briefs.", "endpoint": "http://agents.local/summary", "price": 12.0, "category": "Generation"},
    {"agent_idx": 4, "name": "Image Anomaly Detection", "description": "Finds defects or anomalies in images.", "endpoint": "http://agents.local/vision", "price": 20.0, "category": "Vision"},
    {"agent_idx": 5, "name": "Real-time Translation", "description": "Translates text between 50+ languages.", "endpoint": "http://agents.local/translate", "price": 2.0, "category": "Translation"}
]

async def seed_db():
    async with async_session() as db:
        # Check if empty
        result = await db.execute(select(Agent))
        if result.scalars().first():
            print("Database already seeded.")
            return

        print("Seeding database...")
        db_agents = []
        for a in agents_data:
            agent = Agent(name=a["name"], wallet_address=a["wallet"], trust_score=a["trust"])
            db.add(agent)
            db_agents.append(agent)
        
        await db.flush() # get ids

        for s in services_data:
            agent = db_agents[s["agent_idx"]]
            service = Service(
                agent_id=agent.id,
                name=s["name"],
                description=s["description"],
                endpoint=s["endpoint"],
                price=s["price"],
                category=s["category"]
            )
            db.add(service)

        # Add some mock transactions
        tx1 = Transaction(buyer_wallet="BUYER_1", service_id=1, amount=15.0, status="completed", tx_hash="algo_tx_mock_1")
        tx2 = Transaction(buyer_wallet="BUYER_2", service_id=3, amount=8.0, status="completed", tx_hash="algo_tx_mock_2")
        db.add_all([tx1, tx2])
        await db.flush()

        # Add reputation events
        rev1 = ReputationEvent(agent_id=db_agents[0].id, transaction_id=tx1.id, event_type="success", weight=1.0)
        rev2 = ReputationEvent(agent_id=db_agents[2].id, transaction_id=tx2.id, event_type="success", weight=1.0)
        db.add_all([rev1, rev2])
        
        await db.commit()
        print("Seeding complete.")

if __name__ == "__main__":
    asyncio.run(seed_db())

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.models.domain import Transaction

router = APIRouter()

@router.get("/")
async def get_transactions(wallet: str = None, db: AsyncSession = Depends(get_db)):
    query = select(Transaction)
    if wallet:
        query = query.where(Transaction.buyer_wallet == wallet)
    result = await db.execute(query)
    return result.scalars().all()

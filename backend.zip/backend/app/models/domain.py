import datetime
from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, JSON
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class Agent(Base):
    __tablename__ = "agents"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    wallet_address = Column(String, index=True)
    trust_score = Column(Float, default=50.0) # 0-100 score
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    services = relationship("Service", back_populates="agent")
    reputation_events = relationship("ReputationEvent", back_populates="agent")

class Service(Base):
    __tablename__ = "services"
    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id"))
    name = Column(String)
    description = Column(String)
    endpoint = Column(String)
    price = Column(Float)
    category = Column(String)
    
    agent = relationship("Agent", back_populates="services")

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True, index=True)
    buyer_wallet = Column(String)
    service_id = Column(Integer, ForeignKey("services.id"))
    amount = Column(Float)
    status = Column(String) # "pending", "escrow_locked", "completed", "failed", "refunded"
    tx_hash = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class ReputationEvent(Base):
    __tablename__ = "reputation_events"
    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id"))
    transaction_id = Column(Integer, ForeignKey("transactions.id"))
    event_type = Column(String) # "success", "failure", "timeout"
    weight = Column(Float)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    agent = relationship("Agent", back_populates="reputation_events")

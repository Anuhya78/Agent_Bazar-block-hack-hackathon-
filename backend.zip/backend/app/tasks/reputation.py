from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.domain import Agent, ReputationEvent

async def update_trust_score(agent_id: int, event_type: str, db: AsyncSession):
    event = ReputationEvent(
        agent_id=agent_id,
        event_type=event_type,
        weight=1.0 if event_type == "success" else -1.0
    )
    db.add(event)
    
    # Calculate new score
    agent = await db.get(Agent, agent_id)
    if agent:
        if event_type == "success":
            agent.trust_score = min(100.0, agent.trust_score + 2.5)
        else:
            agent.trust_score = max(0.0, agent.trust_score - 5.0)
            
    await db.commit()

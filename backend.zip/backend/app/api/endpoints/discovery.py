from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.db.session import get_db
from app.models.domain import Service, Agent

router = APIRouter()

@router.get("/")
async def discover_agents(category: str = None, min_trust: float = None, db: AsyncSession = Depends(get_db)):
    query = select(Agent).options(selectinload(Agent.services))
    if min_trust is not None:
        query = query.where(Agent.trust_score >= min_trust)
    
    result = await db.execute(query)
    agents = result.scalars().all()
    
    # Optional category filter in python for simplicity if needed
    if category:
        agents = [a for a in agents if any(s.category == category for s in a.services)]
    
    return agents

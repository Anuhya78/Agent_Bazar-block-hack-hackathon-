from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
import json

class X402Middleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Only apply to specific service execution endpoints
        if request.url.path.startswith("/api/services/") and "/execute" in request.url.path:
            # Check for X-402-Payment-Receipt header
            payment_receipt = request.headers.get("X-402-Payment-Receipt")
            
            if not payment_receipt:
                # Return 402 Payment Required
                service_id = request.url.path.split("/")[3]
                return JSONResponse(
                    status_code=402,
                    content={
                        "error": "Payment Required",
                        "x402_invoice": {
                            "service_id": service_id,
                            "amount": 10.0, # This would ideally be fetched dynamically
                            "currency": "ALGO",
                            "escrow_address": "TEST_ESCROW_ADDRESS_XYZ"
                        }
                    }
                )
        
        response = await call_next(request)
        return response

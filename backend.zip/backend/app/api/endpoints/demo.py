from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.services.ai.negotiation import run_negotiation
from app.services.blockchain.provider import get_provider
from app.tasks.reputation import update_trust_score
import asyncio
import uuid

router = APIRouter()

@router.post("/scenario")
async def run_demo_scenario(db: AsyncSession = Depends(get_db)):
    # 1. Discovery
    # Mocking a discovered service
    service_info = {"id": 1, "name": "Sentiment Analysis", "price": 10.0, "agent_id": 2}
    
    # 2. Negotiation
    negotiated_price = await run_negotiation(buyer_budget=8.0, seller_price=service_info["price"])
    
    # 3. 402 Flow & Escrow
    provider = get_provider()
    tx_hash = await provider.lock_funds(amount=negotiated_price, buyer="BUYER_WALLET", escrow="ESCROW_ADDRESS")
    
    # 4. Execution (mock delay)
    await asyncio.sleep(2)
    
    # 5. Release Escrow
    await provider.release_funds(tx_hash=tx_hash)
    
    # 6. Reputation Update
    await update_trust_score(agent_id=service_info["agent_id"], event_type="success", db=db)
    
    return {
        "status": "completed",
        "pipeline": [
            {"step": "discovery", "message": "Found service Sentiment Analysis"},
            {"step": "negotiation", "message": f"Negotiated price: {negotiated_price} ALGO"},
            {"step": "402_payment", "message": "Received 402 Payment Required"},
            {"step": "escrow_lock", "message": f"Locked {negotiated_price} ALGO in smart contract", "tx": tx_hash},
            {"step": "execution", "message": "Service executed successfully"},
            {"step": "escrow_release", "message": "Funds released to seller"},
            {"step": "reputation", "message": "Seller trust score updated"}
        ]
    }

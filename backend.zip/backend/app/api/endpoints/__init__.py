from fastapi import APIRouter
from . import registry, discovery, transactions, demo

api_router = APIRouter()
api_router.include_router(registry.router, prefix="/services", tags=["services"])
api_router.include_router(discovery.router, prefix="/discovery", tags=["discovery"])
api_router.include_router(transactions.router, prefix="/transactions", tags=["transactions"])
api_router.include_router(demo.router, prefix="/demo", tags=["demo"])

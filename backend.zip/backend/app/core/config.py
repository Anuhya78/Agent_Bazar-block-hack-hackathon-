from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "AgentBazaar"
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/agentbazaar"
    PAYMENT_PROVIDER: str = "mock" # 'mock' or 'algorand'
    
    class Config:
        env_file = ".env"

settings = Settings()

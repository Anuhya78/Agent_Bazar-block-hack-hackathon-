import asyncio

async def run_negotiation(buyer_budget: float, seller_price: float) -> float:
    # A LangGraph agent would normally run here.
    # For out-of-the-box demo without API keys, we simulate a successful negotiation.
    await asyncio.sleep(1) # simulate thinking
    agreed_price = (buyer_budget + seller_price) / 2
    return round(agreed_price, 2)

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.session import get_db
from app.models.domain import Service, Agent
from pydantic import BaseModel
from typing import List

router = APIRouter()

class ServiceCreate(BaseModel):
    agent_id: int
    name: str
    description: str
    endpoint: str
    price: float
    category: str

@router.post("/")
async def register_service(service: ServiceCreate, db: AsyncSession = Depends(get_db)):
    new_service = Service(**service.dict())
    db.add(new_service)
    await db.commit()
    await db.refresh(new_service)
    return new_service

@router.get("/")
async def list_services(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Service))
    return result.scalars().all()

@router.post("/{service_id}/execute")
async def execute_service(service_id: int):
    # If middleware didn't return 402, payment is assumed valid for demo purposes
    return {"status": "success", "data": f"Service {service_id} executed successfully with verified payment."}

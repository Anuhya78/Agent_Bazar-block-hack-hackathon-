import uuid
from app.core.config import settings

class PaymentProvider:
    async def lock_funds(self, amount: float, buyer: str, escrow: str) -> str:
        pass
    async def release_funds(self, tx_hash: str) -> bool:
        pass

class MockPaymentProvider(PaymentProvider):
    async def lock_funds(self, amount: float, buyer: str, escrow: str) -> str:
        return f"mock_tx_{uuid.uuid4().hex[:8]}"
        
    async def release_funds(self, tx_hash: str) -> bool:
        return True

class AlgorandPaymentProvider(PaymentProvider):
    async def lock_funds(self, amount: float, buyer: str, escrow: str) -> str:
        # Placeholder for py-algorand-sdk interaction
        return f"algo_tx_{uuid.uuid4().hex[:8]}"
        
    async def release_funds(self, tx_hash: str) -> bool:
        return True

def get_provider() -> PaymentProvider:
    if settings.PAYMENT_PROVIDER == "mock":
        return MockPaymentProvider()
    return AlgorandPaymentProvider()
